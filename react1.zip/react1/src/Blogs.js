const Blogs=()=>{
    return<h1>Blog Artices</h1>;
};
export default Blogs;